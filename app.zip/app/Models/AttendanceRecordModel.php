<?php

namespace App\Models;

use CodeIgniter\Model;

class AttendanceRecordModel extends Model {
    protected $table = 'attendance_record';

    protected $primaryKey = 'id';

    protected $allowedFields = ['id','names', 'sfid', 'district', 'sector', 'attendance_id'];
    protected $useTimestamps = true;
}

