<?php

namespace App\Models;

use CodeIgniter\Model;
use SebastianBergmann\Type\FalseType;

class UsersModel extends Model {
    protected $table = 'users';

    protected $primaryKey = 'id';

    protected $allowedFields = ['id', 'names', 'email', 'password', 'status'];
    protected $useTimestamps = true;
    public function checkUser($value, $key = "login"){
        $resBuilder = $this->select('id, names, password, email, status')->where("(email = '$value' or names like '%$value%')");
        if ($key == 'login'){
        } 
        return $resBuilder->get()->getRow();
    }
}