<?php

namespace App\Controllers;

use App\Models\AdminModel;
use App\Models\AttendanceModel;
use App\Models\AttendanceRecordModel;
use App\Models\DistrictModel;
use App\Models\StaffsModel;
use App\Models\NewsModel;
use App\Models\ParentModel;
use App\Models\UsersModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use ArrayAccess;
use \Firebase\JWT\JWT;
use Firebase\JWT\Key;

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\RoundBlockSizeMode;
use Endroid\QrCode\Writer\PngWriter;

class Home extends BaseController
{
    // private Redis $redis;
    private $accessData;

    public function index()
    {
        return $this->response->setStatusCode(200)->setJSON(["message" => "eiaq api is well configured"]);
    }
    public function _secure()
    {
        $this->appendHeader();
        $token = $this->request->getHeader('Authorization')->getValue();
        $key = getenv('JWT_SECRET');

        try {
            if (is_null($token) || empty($token)) {
                return $this->response->setStatusCode(401)->setJSON(['error' => 'Unauthorized', "message" => "token is empty"]);
            }
            // Decode the token
            $this->accessData = JWT::decode($token, new Key($key, 'HS256'));
            // var_dump($this->accessData); die();

            if (!$this->accessData) {
                // Token is invalid or expired
                return $this->response->setStatusCode(401)->setJSON(['error' => 'Unauthorized', "message" => "Token is invalid or expired"]);
            }
        } catch (\Exception $e) {
            return $this->response->setStatusCode(401)->setJSON(['error' => 'Unauthorized', "message" => $e->getMessage()]);
        }
    }
    public function login()
    {
        $this->appendHeader();
        $model = new UsersModel();
        $input = $this->request->getJSON();

        try {
            $email = $input->email;
            $password = $input->password;
            $key = 'email';
            $result = $model->checkUser($email, $key);
            if ($result != null) {
                if (password_verify($password, $result->password)) {
                    if ($result->status == 1) {
                        $payload = array(
                            "iat" => time(),
                            "name" => $result->names,
                            'email' => $result->email,
                            "uid" => $result->id,
                        );
                        $key = getenv('JWT_SECRET');
                        $token = JWT::encode($payload, $key, 'HS256');

                        $data = array(
                            "uid" => $result->id,
                            "name" => $result->names,
                            'email' => $result->email,
                            "token" => $token,
                        );
                        return $this->response->setStatusCode(200)->setJSON($data);
                    } else {
                        return $this->response->setStatusCode(400)->setJSON(array("error" => lang('accountLocked'), "message" => lang('app.yourAccountLocked')));
                    }
                } else {
                    return $this->response->setStatusCode(403)->setJSON(array("error" => lang('invalidLogin'), "message" => lang('app.usernamePasswordNotCorrect')));
                }
            } else {
                return $this->response->setStatusCode(403)->setJSON(["error" =>
                lang('invalidLogin'), "message" => lang('app.usernamePasswordNotCorrect')]);
            }
        } catch (\Exception $e) {
            return $this->response->setStatusCode(403)->setJSON(array("error" => lang('invalidLogin'), "message" => lang('app.provideRequiredData') . $e->getMessage()));
        }
    }
    function getAttendance($output = 0, $limit = '')
    {
        // empty($token) ? $this->_secure() : $this->_secure($token);
        $this->appendHeader();
        $mdl = new AttendanceRecordModel();
        $resultBuilder = $mdl->select("attendance_record.id,attendance_record.names,attendance_record.sfid,attendance_record.sector,attendance_id,d.title as district,DATE(attendance_record.created_at) as event_date")
            ->join('districts d', "d.id = district");
        if ($limit != '') {
            $result = $resultBuilder->limit($limit);
        }
        $result = $resultBuilder->get()->getResultArray();
        if ($output != 0) {
            try {
                $spreadsheet = new Spreadsheet();
                $worksheet = $spreadsheet->getActiveSheet();
                $styleArray = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_HAIR,
                            'color' => ['argb' => 'FFFFFFFF'],
                            'size' => $spreadsheet->getDefaultStyle()->getFont()->setSize(14)
                        ]
                    ],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['argb' => 'FF058e8c'],
                    ],
                    'font' => [
                        'bold' => true,
                        'color' => ['argb' => 'FFFFFFFF'],
                    ],
                    'alignment' => [
                        'vertical' => Alignment::VERTICAL_CENTER
                    ]
                ];
                $worksheet->getStyle('A3:F3')->applyFromArray($styleArray);
                $worksheet->getCell('A3')->setValue('#');
                $worksheet->getCell('B3')->setValue('Names');
                $worksheet->getCell('C3')->setValue('Success factor ID');
                $worksheet->getCell('D3')->setValue('District');
                $worksheet->getCell('E3')->setValue('Site');
                $worksheet->getCell('F3')->setValue('Date');

                $i = 4;
                foreach ($result as $res) {


                    $worksheet->getCell('A' . $i)->setValue($res['id']);
                    $worksheet->getCell('B' . $i)->setValue($res['names']);
                    $worksheet->getCell('C' . $i)->setValue($res['sfid']);
                    $worksheet->getCell('D' . $i)->setValue($res['district']);
                    $worksheet->getCell('E' . $i)->setValue($res['sector']);
                    $worksheet->getCell('E' . $i)->setValue($res['event_date']);

                    $worksheet->getRowDimension($i)->setRowHeight(20);

                    $i++;
                }
                $worksheet->setTitle("List of Attendiese");
                $worksheet->getTabColor()->setARGB('FF058e8c');
                $writer = IOFactory::createWriter($spreadsheet, 'Xls');
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Access-Control-Expose-Headers: Content-Disposition');
                header('Content-Disposition: attachment; filename="List of Attendiese - ' . date('Y-m-d') . '.xls"');
                $writer->save("php://output");
            } catch (\Exception $e) {
                return $this->response->setStatusCode(500)->setJSON(["message" => $e->getMessage()]);
            }
        }
        return $this->response->setJSON($result);
    }

    public function createAttendance()
    {
        $this->appendHeader();
        $mdl = new AttendanceModel();
        $districtMdl = new DistrictModel();
        $data = [
            'operator' => '1',
            'status' => 0,
        ];

        $attendance_id = $mdl->insert($data);
        $result = $districtMdl->findAll();
        // var_dump($this->accessData); die();
        foreach ($result as $res) {
            $url = getenv('QRCODE_URL') . 'generateQrCode/' . $res['id'] . '/' . $attendance_id;
            $data = [
                'url' => $url,
                'district' => $res['title'],
            ];
            $message = view('email', $data);
            $this->sendMail($res['email'],  'Lisiti y\'ubwitabire', $message,);
        }

        return $this->response->setJSON(['message' => 'Attendate is succefully created']);
    }

    public function generateQrCode($district = '1', $attendance_id = '2')
    {

        $qrCodeLink = getenv('FORM_URL') . 'ubwitabire?di='  . $district . '&at=' . $attendance_id;
        // Generate the QR code with the provided link
        $result = Builder::create()
            ->writer(new PngWriter())
            ->data($qrCodeLink)
            ->encoding(new Encoding('UTF-8'))
            ->size(300)
            ->margin(10)
            ->build();

        // Pass the QR code image data to the view
        $data['qrCodeImage'] = $result->getDataUri();

        // Get the user's IP address
        $ipAddress = $_SERVER['REMOTE_ADDR'];

        // Use an IP geolocation service to get latitude and longitude
        $geoData = json_decode(file_get_contents("http://ip-api.com/json/{$ipAddress}"), true);

        // var_dump($geoData); die();
        // Check if the data is available and valid
        if ($geoData && $geoData['status'] == 'success') {
            $latitude = $geoData['lat'];
            $longitude = $geoData['lon'];
        } else {
            // Default coordinates if unable to fetch from IP geolocation
            $latitude = 0;
            $longitude = 0;
        }

        // Create JWT payload with QR code link, latitude, and longitude
        $payload = [
            'qr_code_link' => $qrCodeLink,
            'latitude' => $latitude,
            'longitude' => $longitude
        ];
        $key = getenv('JWT_SECRET');
        JWT::encode($payload, $key, 'HS256');

        // Pass the JWT token to the view 'attendance-qrcode'
        $data['qrCodeImage'] = $result->getDataUri();
        $data['latitude'] = $latitude;
        $data['longitude'] = $longitude;

        return view('attendance-qrcode', $data);
    }

    public function saveAttendance()
    {
        $this->_secure();
        $mdl = new AttendanceRecordModel();
        $input = $this->request->getJSON();
        $data = [
            'attendance_id' => $input->attendance_id,
            'names' => $input->formData->name,
            'sfid' => $input->formData->sfid,
            'sector' => $input->formData->site,
            'district' => $input->district
        ];
        $result = $mdl->insert($data);
        return $this->response->setJSON(['message' => 'Attendate is succefully created']);
    }
}
